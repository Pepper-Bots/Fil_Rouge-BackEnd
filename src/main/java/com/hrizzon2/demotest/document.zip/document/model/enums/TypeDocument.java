package com.hrizzon2.demotest.document.model.enums;

public enum TypeDocument {

    JUSTIFICATIF, // Pour absences et retards
    PIECE_IDENTITE,
    DIPLOME_BAC,
    DIPLOME_BAC_2,
    DIPLOME_BAC_3,
    CV,
    LETTRE_MOTIVATION,
    JUSTIF_SITUATION,
    PORTFOLIO,
    ATTEST_RESP_CIVILE,
    AUTRE
}

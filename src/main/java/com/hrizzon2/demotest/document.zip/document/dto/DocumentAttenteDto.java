package com.hrizzon2.demotest.document.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DocumentAttenteDto {

    private String nomFichier;
    private String stagiaireNom;
    private String urlFichier;
}
